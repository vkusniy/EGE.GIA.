﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CosmeticShop
{
    public partial class ChangeProductForm : Form
    {
        public Model1 db { get; set; }

        public ChangeProductForm()
        {
            InitializeComponent();
        }
    }
}
